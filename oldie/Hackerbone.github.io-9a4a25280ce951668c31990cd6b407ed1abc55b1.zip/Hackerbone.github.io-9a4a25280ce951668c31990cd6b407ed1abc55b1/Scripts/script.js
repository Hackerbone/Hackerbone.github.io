
$(document).ready(function(){
  $(".name").fadeOut(0);
  $(".username").fadeOut(0);
    setTimeout(function(){
      $(".name").slideDown(500);
      $(".username").slideDown();}, 950);

});
